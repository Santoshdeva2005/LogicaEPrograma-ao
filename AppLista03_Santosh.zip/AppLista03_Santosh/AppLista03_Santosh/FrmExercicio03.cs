﻿using System.Windows.Forms;

namespace AppLista03_Santosh
{
    public partial class FrmExercicio03 : Form
    {
        public FrmExercicio03()
        {
            InitializeComponent();
        }

        private void FrmExercicio03_Load(object sender, System.EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, System.EventArgs e)
        {
            //Capturar Valores da Tela
           


        }

        private void label2_Click(object sender, System.EventArgs e)
        {

        }

        private void txtPeso_TextChanged(object sender, System.EventArgs e)
        {
            //Valores
            float vlrPeso = float.Parse(txtPeso.Text);
            float vlrPrato;

            //Calculo
            vlrPrato = vlrPeso * 34;

            //Mostrar Resultado
            lblValor.Text = vlrPrato + "Reais";
        }
    }
}

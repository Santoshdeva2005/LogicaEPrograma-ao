﻿using System.Windows.Forms;

namespace AppLista03_Santosh
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void FrmExercicio01_Load(object sender, System.EventArgs e)
        {

        }
    }
}

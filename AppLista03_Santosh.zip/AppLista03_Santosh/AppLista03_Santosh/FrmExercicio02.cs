﻿using System.Windows.Forms;

namespace AppLista03_Santosh
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, System.EventArgs e)
        {
            //Capturar valores da tela
            float vlrPagar = float.Parse(txtValorPagar.Text);
            float vlrLitro = float.Parse(txtLitro.Text);
            float qtdLitros;

            //Calculo
            qtdLitros = vlrPagar / vlrLitro;

           //Mostrar resultado
            lblResultado.Text = qtdLitros + "litros";

        }

        private void lblFoi_Load(object sender, System.EventArgs e)
        {

        }
    }
}
